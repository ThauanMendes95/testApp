package app

import (
	"fmt"
	"log"
	"net"

	"github.com/urfave/cli"
)

// Gerar vai retornar a aplicação de linha de comando pronta para ser executada
func Gerar() *cli.App {
	app := cli.NewApp()
	app.Name = "Aplicação de Linha de Comando"
	app.Usage = "Busca de IP's e Nomes de Servidor na Internet"

	// parametros -- flags são parametros de como os dados têm que ser recebidos
	flags := []cli.Flag{
		cli.StringFlag{
			Name:  "host",
			Value: "youtube.com.br",
		},
	}
	// criando comandos
	app.Commands = []cli.Command{
		{
			Name:   "ip",
			Usage:  "Busca IP's de endereços na internet",
			Flags:  flags, // mandar a flags de acordo com os parametros criado acima (linha 12)
			Action: buscarIps,
		},
		{
			Name:   "servidores",
			Usage:  "Buscar nome dos servidores na internet",
			Flags:  flags,
			Action: buscaServidores,
		},
	}
	return app
}

func buscarIps(c *cli.Context) {
	host := c.String("host") // adicionando o host recebido em uma variavel

	ips, erro := net.LookupIP(host) // lookupIP busca os ips publicos dos sites.. buscando ips publicos da variavel host
	if erro != nil {
		log.Fatal(erro)
	}

	for _, ip := range ips {
		fmt.Println(ip)
	}
}

func buscaServidores(c *cli.Context) {
	host := c.String("host") // adicionando o host recebido em uma variavel

	servidores, erro := net.LookupNS(host) // lookupNS busca os servidores publicos.. buscando servidores publicos da variavel host
	if erro != nil {
		log.Fatal(erro)
	}

	for _, servidor := range servidores {
		fmt.Println(servidor.Host)
	}
}

// exemplo de uso "go run main.go ip --host amazon.com.br"
// exemplo de uso "go run main.go servidores --host amazon.com.br"
