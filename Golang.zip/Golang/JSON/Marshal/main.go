package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
)

type cachorro struct {
	Nome  string `json:"nome"`
	Raca  string `json:"raca"`
	Idade int    `json:"idade"`
}

func main() {
	c := cachorro{
		Nome:  "Rex",
		Raca:  "Dálmata",
		Idade: 5,
	}
	fmt.Println(c) //

	cachorroEmJSON, erro := json.Marshal(c)
	if erro != nil {
		log.Fatal(erro)
	}

	fmt.Println(cachorroEmJSON)                  //retorna o json em bytes
	fmt.Println(bytes.NewBuffer(cachorroEmJSON)) // converte os bytes em json
}
