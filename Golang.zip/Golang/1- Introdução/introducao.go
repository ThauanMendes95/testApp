package main

import (
	"fmt"
	endereco "rato/endereço"
)

func main() {
	tipoEndereco := endereco.TipoDeEndereco("Avenida Paulista")
	fmt.Println(tipoEndereco)
}
