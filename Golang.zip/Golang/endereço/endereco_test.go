// TESTE DE UNIDADE
package endereco

import (
	"testing"
)

type cenarioDeTeste struct {
	enderecoInserido string
	retornoEsperado  string
}

func TestTipoDeEndereco(t *testing.T) {

	cenariosDeTeste := []cenarioDeTeste{
		//endereço recebido - retornoEsperado
		{"Rua ABC", "Rua"},
		{"Avenida Paulista", "Avenida"},
		{"Rodovia dos Imigrantes", "Rodovia"},
		{"Estrada das Lagrimas", "Estrada"},
		{"RUA GUIMARÃES PASSOS", "Rua"},
		{"", "Tipo Inválido"},
		{"Praça das Rosas", "Tipo Inválido"},
		{"AVENIDA JABAQUARA", "Avenida"},
	}

	for _, cenario := range cenariosDeTeste {
		tipoDeEnderecoRecebido := TipoDeEndereco(cenario.enderecoInserido)
		if tipoDeEnderecoRecebido != cenario.retornoEsperado {
			t.Errorf("O tipo recebido %s é diferente do esperado %s", tipoDeEnderecoRecebido, cenario.retornoEsperado)
		}
	}
}
