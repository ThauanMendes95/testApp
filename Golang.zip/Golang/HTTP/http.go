package main

import (
	"log"
	"net/http"
)

func raiz(w http.ResponseWriter, e *http.Request) {
	w.Write([]byte("Pagina Raiz"))
}

func home(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Página home. Manucu!"))
}
func usuarios(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Carregar página de usuarios!"))
}

func main() {
	// HTTP É UM PROTOCOLO DE COMUNICAÇÃO - BASE DA COMUNICAÇÃO WEB

	// CLIENTE (FAZ REQUISIÇÃO) - SERVIDOR (PROCESSA REQUISIÇÃO E ENVIA RESPOSTA)
	//          REQUEST(r)      -                   RESPONSE(w)

	// Rotas
	// URI - Identificador do Recurso (caminho, ex: /home)
	// Método - GET(Buscar dados), POST(Cadastrar dados), PUT(Atualizar dados), DELETE(Deletar dados)

	http.HandleFunc("/", raiz)

	http.HandleFunc("/home", home)

	http.HandleFunc("/home/usuarios", usuarios)

	log.Fatal(http.ListenAndServe(":5000", nil)) //servidor local, rodar o script e acessar o "localhost:5000" no navegador

}
